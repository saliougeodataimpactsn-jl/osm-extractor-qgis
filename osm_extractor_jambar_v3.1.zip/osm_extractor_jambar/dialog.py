# -*- coding: utf-8 -*-
"""
OSM Extractor by Jambar Lab — Dialogue principal.

Améliorations v3.1 :
  - Layout compact 2 colonnes (catégories + options)
  - Sélection de toutes les couches (pas seulement la couche active)
  - Checkbox avec ✔ visible en texte
  - Compatible QGIS 3.16+ et QGIS 4.x (PyQt5 / PyQt6)
  - Index spatial créé avant le clip → plus d'avertissement
  - Identité visuelle Jambar Lab (vert + "Jambar Lab" en orange gras)
"""

import logging

from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QCheckBox, QPushButton, QProgressBar,
    QGroupBox, QFrame, QSizePolicy, QWidget,
)
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.PyQt.QtGui import QFont

from qgis.core import QgsProject, QgsMapLayer
from qgis.gui import QgsMapLayerComboBox

from .compat import (
    Qt_AlignCenter, Qt_AlignLeft, Qt_AlignVCenter,
    SP_Fixed, SP_Preferred, SP_Expanding,
    vector_layer_filter,
)
from .osm_logic import (
    CATEGORIES, get_bbox_wgs84, build_query,
    fetch_overpass, osm_to_layer, clip_layer,
)

log = logging.getLogger("JambarOSM")

# ─────────────────────────────────────────────────────────────────────────────
# PALETTE JAMBAR LAB
# ─────────────────────────────────────────────────────────────────────────────
C_GREEN       = "#146C43"   # vert principal
C_GREEN_DARK  = "#0f5233"   # vert foncé hover
C_GREEN_LIGHT = "#e8f5ee"   # vert très clair (fond badges)
C_ORANGE      = "#E85D04"   # orange Jambar Lab (uniquement pour le nom)
C_BG          = "#FFFFFF"   # fond blanc
C_SURFACE     = "#f8fafb"   # surface légèrement grisée
C_BORDER      = "#dde3e9"   # bordures
C_TEXT        = "#1a2332"   # texte principal
C_TEXT_MUTED  = "#64748b"   # texte secondaire
C_DANGER      = "#c0392b"   # erreur

# ─────────────────────────────────────────────────────────────────────────────
# STYLESHEET COMPACTE
# ─────────────────────────────────────────────────────────────────────────────
STYLESHEET = f"""
QDialog {{
    background-color: {C_BG};
    color: {C_TEXT};
    font-family: "Segoe UI", "Ubuntu", sans-serif;
    font-size: 9pt;
}}

/* Groupes */
QGroupBox {{
    background-color: {C_BG};
    border: 1px solid {C_BORDER};
    border-radius: 5px;
    margin-top: 10px;
    padding: 6px 8px 6px 8px;
    font-size: 8pt;
    font-weight: bold;
    color: {C_GREEN};
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    left: 8px;
    padding: 0 4px;
    background-color: {C_BG};
}}

/* Labels */
QLabel {{ color: {C_TEXT}; background: transparent; }}

/* ComboBox couches */
QgsMapLayerComboBox, QComboBox {{
    background-color: {C_SURFACE};
    border: 1px solid {C_BORDER};
    border-radius: 4px;
    padding: 3px 6px;
    color: {C_TEXT};
    font-size: 9pt;
    min-height: 24px;
}}
QgsMapLayerComboBox:focus, QComboBox:focus {{
    border-color: {C_GREEN};
}}
QComboBox::drop-down {{ border: none; width: 18px; }}
QComboBox QAbstractItemView {{
    background-color: {C_BG};
    selection-background-color: {C_GREEN_LIGHT};
    color: {C_TEXT};
    border: 1px solid {C_BORDER};
}}

/* Checkboxes — indicateur natif masqué, le ✔ est dans le texte */
QCheckBox {{
    color: {C_TEXT};
    spacing: 4px;
    font-size: 9pt;
    padding: 1px 0;
}}
QCheckBox::indicator {{
    width: 0px;
    height: 0px;
}}

/* Bouton principal */
QPushButton#btn_run {{
    background-color: {C_GREEN};
    color: #FFFFFF;
    border: none;
    border-radius: 4px;
    padding: 7px 22px;
    font-size: 9pt;
    font-weight: bold;
    min-height: 30px;
}}
QPushButton#btn_run:hover   {{ background-color: {C_GREEN_DARK}; }}
QPushButton#btn_run:pressed {{ background-color: #0a3d26; }}
QPushButton#btn_run:disabled {{
    background-color: #adb5bd;
    color: #e9ecef;
}}

/* Barre de progression */
QProgressBar {{
    border: 1px solid {C_BORDER};
    border-radius: 3px;
    background-color: {C_SURFACE};
    text-align: center;
    color: {C_TEXT_MUTED};
    font-size: 8pt;
    max-height: 16px;
}}
QProgressBar::chunk {{
    background-color: {C_GREEN};
    border-radius: 2px;
}}

/* Séparateur */
QFrame#sep {{ color: {C_BORDER}; }}
"""

# ─────────────────────────────────────────────────────────────────────────────
# CHECKBOX PERSONNALISÉE — affiche ✔ ou ○ dans le texte
# ─────────────────────────────────────────────────────────────────────────────

class IndicatorCheckBox(QCheckBox):
    """
    QCheckBox dont le texte commence par '✔ ' (coché) ou '○ ' (décoché).
    L'indicateur natif Qt est masqué (width/height = 0 dans le stylesheet).
    """

    CHECKED_PREFIX   = "✔  "
    UNCHECKED_PREFIX = "○  "

    def __init__(self, label, parent=None):
        self._raw_label = label
        super().__init__(self.UNCHECKED_PREFIX + label, parent)
        self.toggled.connect(self._refresh_text)

    def _refresh_text(self, checked):
        prefix = self.CHECKED_PREFIX if checked else self.UNCHECKED_PREFIX
        self.setText(prefix + self._raw_label)
        # Couleur du préfixe selon état
        color = C_GREEN if checked else C_TEXT_MUTED
        self.setStyleSheet(
            f"QCheckBox {{ color: {C_TEXT}; }}"
            # on ne peut pas colorer juste le prefix — on colore tout sobrement
        )


# ─────────────────────────────────────────────────────────────────────────────
# THREAD D'EXTRACTION
# ─────────────────────────────────────────────────────────────────────────────

class ExtractionWorker(QThread):

    progress    = pyqtSignal(int)
    status      = pyqtSignal(str)
    layer_ready = pyqtSignal(object, str)   # (QgsVectorLayer, category_key)
    finished    = pyqtSignal(bool, str)

    def __init__(self, bbox, keys, parent=None):
        super().__init__(parent)
        self.bbox      = bbox
        self.keys      = keys
        self._stop     = False

    def cancel(self):
        self._stop = True

    def run(self):
        total     = len(self.keys)
        n_ok      = 0
        n_empty   = 0
        n_err     = 0

        for i, key in enumerate(self.keys):
            if self._stop:
                self.finished.emit(False, "Extraction annulée.")
                return

            label    = CATEGORIES[key]["label"]
            base_pct = int(i / total * 100)

            self.progress.emit(base_pct)
            self.status.emit(f"↓ {label}…")
            log.info(f"[{i+1}/{total}] {label}")

            query       = build_query(self.bbox, key)
            data, err   = fetch_overpass(query)
            self.progress.emit(base_pct + int(55 / total))

            if err:
                self.status.emit(f"⚠ {label} : {err}")
                log.error(f"{label} : {err}")
                n_err += 1
                continue

            if self._stop:
                self.finished.emit(False, "Extraction annulée.")
                return

            self.status.emit(f"↻ Conversion {label}…")
            layer, cerr = osm_to_layer(data, key)
            self.progress.emit(base_pct + int(85 / total))

            if cerr:
                self.status.emit(f"∅ {label} : {cerr}")
                log.warning(f"{label} : {cerr}")
                n_empty += 1
                continue

            self.layer_ready.emit(layer, key)
            n_ok += 1

        self.progress.emit(100)

        parts = []
        if n_ok:    parts.append(f"{n_ok} couche(s) extraite(s)")
        if n_empty: parts.append(f"{n_empty} sans données")
        if n_err:   parts.append(f"{n_err} erreur(s) réseau")
        self.finished.emit(n_ok > 0, " · ".join(parts) or "Aucun résultat.")


# ─────────────────────────────────────────────────────────────────────────────
# DIALOGUE PRINCIPAL
# ─────────────────────────────────────────────────────────────────────────────

class OsmExtractorDialog(QDialog):
    """Boîte de dialogue principale — compacte, 2 colonnes, palette Jambar."""

    def __init__(self, iface, parent=None):
        super().__init__(parent or iface.mainWindow())
        self.iface  = iface
        self.worker = None

        self.setWindowTitle("OSM Extractor")
        self.setFixedWidth(400)          # largeur fixe — compact
        self.setStyleSheet(STYLESHEET)

        self._build_ui()

    # ── Construction ──────────────────────────────────────────────────────────

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setSpacing(8)
        root.setContentsMargins(14, 12, 14, 12)

        # En-tête compact (1 ligne)
        root.addWidget(self._make_header())

        # Couche — QgsMapLayerComboBox (toutes les couches vecteur)
        root.addWidget(self._make_layer_group())

        # Catégories OSM + Options côte à côte (2 colonnes)
        cols = QHBoxLayout()
        cols.setSpacing(8)
        cols.addWidget(self._make_categories_group())
        cols.addWidget(self._make_options_group())
        root.addLayout(cols)

        # Progression + statut
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setFormat("Prêt")
        self.progress_bar.setVisible(False)
        root.addWidget(self.progress_bar)

        self.lbl_status = QLabel("")
        self.lbl_status.setAlignment(Qt_AlignCenter)
        self.lbl_status.setStyleSheet(
            f"font-size: 8pt; color: {C_TEXT_MUTED}; padding: 0px;"
        )
        self.lbl_status.setVisible(False)
        root.addWidget(self.lbl_status)

        # Bouton
        self.btn_run = QPushButton("Lancer l'extraction")
        self.btn_run.setObjectName("btn_run")
        self.btn_run.clicked.connect(self._on_run)
        root.addWidget(self.btn_run)

        # Pied de page
        sep = QFrame()
        sep.setObjectName("sep")
        sep.setFrameShape(QFrame.Shape.HLine if hasattr(QFrame, "Shape")
                          else QFrame.HLine)
        root.addWidget(sep)

        lbl_foot = QLabel("Données © OpenStreetMap contributors · ODbL")
        lbl_foot.setAlignment(Qt_AlignCenter)
        lbl_foot.setStyleSheet(f"font-size: 7pt; color: {C_TEXT_MUTED};")
        root.addWidget(lbl_foot)

    def _make_header(self):
        """En-tête horizontal compact : titre à gauche, badge version à droite."""
        frame = QFrame()
        frame.setStyleSheet("QFrame { background: transparent; border: none; }")
        lay = QHBoxLayout(frame)
        lay.setContentsMargins(0, 0, 0, 4)
        lay.setSpacing(6)

        # "OSM Extractor" en vert + "by Jambar Lab" en orange gras — une seule ligne
        lbl = QLabel()
        lbl.setText(
            f'<span style="font-size:14pt; font-weight:bold; color:{C_GREEN};">'
            f'OSM Extractor</span>'
            f'<span style="font-size:9pt; color:{C_TEXT_MUTED};"> by </span>'
            f'<span style="font-size:9pt; font-weight:bold; color:{C_ORANGE};">'
            f'Jambar Lab</span>'
        )
        lbl.setTextFormat(Qt.TextFormat.RichText if hasattr(Qt, "TextFormat")
                          else Qt.RichText)

        ver = QLabel("v3.1")
        ver.setStyleSheet(
            f"font-size: 7pt; color: #adb5bd; background: {C_SURFACE}; "
            f"border: 1px solid {C_BORDER}; border-radius: 3px; padding: 1px 5px;"
        )

        lay.addWidget(lbl, 1)
        lay.addWidget(ver, 0)
        return frame

    def _make_layer_group(self):
        """Sélecteur de couche — toutes les couches vecteur du projet."""
        group = QGroupBox("Zone d'extraction")
        lay   = QVBoxLayout(group)
        lay.setSpacing(4)
        lay.setContentsMargins(6, 4, 6, 6)

        hint = QLabel("Choisir une couche :")
        hint.setStyleSheet(f"font-size: 8pt; color: {C_TEXT_MUTED};")
        lay.addWidget(hint)

        self.layer_combo = QgsMapLayerComboBox()
        self.layer_combo.setFilters(vector_layer_filter())
        self.layer_combo.setAllowEmptyLayer(False)
        lay.addWidget(self.layer_combo)

        return group

    def _make_categories_group(self):
        """Catégories OSM avec checkbox ✔/○."""
        group = QGroupBox("Types de données")
        lay   = QVBoxLayout(group)
        lay.setSpacing(2)
        lay.setContentsMargins(6, 4, 6, 6)

        self.cat_checks = {}
        for key, cat in CATEGORIES.items():
            cb = IndicatorCheckBox(cat["label"])
            self.cat_checks[key] = cb
            lay.addWidget(cb)

        lay.addStretch()
        return group

    def _make_options_group(self):
        """Options avec checkbox ✔/○."""
        group = QGroupBox("Options")
        lay   = QVBoxLayout(group)
        lay.setSpacing(2)
        lay.setContentsMargins(6, 4, 6, 6)

        self.chk_add  = IndicatorCheckBox("Ajouter à QGIS")
        self.chk_add.setChecked(True)

        self.chk_clip = IndicatorCheckBox("Découper l'emprise")
        self.chk_clip.setChecked(True)

        lay.addWidget(self.chk_add)
        lay.addWidget(self.chk_clip)
        lay.addStretch()
        return group

    # ── Lancement ─────────────────────────────────────────────────────────────

    def _on_run(self):
        # Récupérer la couche sélectionnée dans le combo
        layer = self.layer_combo.currentLayer()
        if layer is None or not layer.isValid():
            self.iface.messageBar().pushWarning(
                "OSM Extractor",
                "Aucune couche valide sélectionnée."
            )
            return

        # Catégories cochées
        keys = [k for k, cb in self.cat_checks.items() if cb.isChecked()]
        if not keys:
            self.iface.messageBar().pushWarning(
                "OSM Extractor",
                "Cochez au moins un type de données."
            )
            return

        bbox = get_bbox_wgs84(layer)
        if bbox is None:
            self.iface.messageBar().pushCritical(
                "OSM Extractor",
                "Impossible de calculer l'emprise. "
                "Vérifiez que la couche a un SCR défini."
            )
            return

        self._clip_source = layer
        self._set_running(True)
        self.iface.messageBar().pushInfo(
            "OSM Extractor",
            f"Extraction de {len(keys)} type(s) en cours…"
        )

        self.worker = ExtractionWorker(bbox, keys, parent=self)
        self.worker.progress.connect(self.progress_bar.setValue)
        self.worker.status.connect(self._on_status)
        self.worker.layer_ready.connect(self._on_layer_ready)
        self.worker.finished.connect(self._on_finished)
        self.worker.start()

    def _on_status(self, msg):
        self.lbl_status.setText(msg)
        self.progress_bar.setFormat(msg[:40] + "…" if len(msg) > 40 else msg)

    def _on_layer_ready(self, layer, key):
        """Clip et ajout dans le thread principal."""
        if self.chk_clip.isChecked():
            layer = clip_layer(layer, self._clip_source)
        if self.chk_add.isChecked():
            QgsProject.instance().addMapLayer(layer)

    def _on_finished(self, success, summary):
        self._set_running(False)
        self.progress_bar.setFormat("Terminé")
        self.lbl_status.setText(summary)

        if success:
            self.iface.messageBar().pushSuccess("OSM Extractor", summary)
        else:
            self.iface.messageBar().pushWarning("OSM Extractor", summary)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _set_running(self, running):
        self.btn_run.setEnabled(not running)
        self.layer_combo.setEnabled(not running)
        for cb in self.cat_checks.values():
            cb.setEnabled(not running)
        self.chk_add.setEnabled(not running)
        self.chk_clip.setEnabled(not running)

        self.progress_bar.setVisible(True)
        self.lbl_status.setVisible(True)
        if running:
            self.progress_bar.setValue(0)
            self.progress_bar.setFormat("Démarrage…")
            self.lbl_status.setText("Connexion à Overpass…")

    def closeEvent(self, event):
        if self.worker and self.worker.isRunning():
            self.worker.cancel()
            self.worker.wait(3000)
        event.accept()
