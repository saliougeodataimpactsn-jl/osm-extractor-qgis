# -*- coding: utf-8 -*-
"""
OSM Extractor by Jambar Lab — Logique métier.
Compatible QGIS 3.16+ et QGIS 4.x.

Modules :
  - CATEGORIES    : catalogue des types de données OSM
  - get_bbox_wgs84: bbox WGS84 d'une couche QGIS
  - build_query   : construction de la requête Overpass QL
  - fetch_overpass: téléchargement via requests (verify=False)
  - osm_to_layer  : conversion JSON → QgsVectorLayer mémoire (avec index spatial)
  - clip_layer    : découpage via native:clip
"""

import json
import logging

from qgis.core import (
    QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY,
    QgsFields, QgsCoordinateReferenceSystem,
    QgsCoordinateTransform, QgsProject,
)
from .compat import make_string_field

# ── Requests ──────────────────────────────────────────────────────────────────
try:
    import requests
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

log = logging.getLogger("JambarOSM")

OVERPASS_URL = "https://overpass-api.de/api/interpreter"

# ─────────────────────────────────────────────────────────────────────────────
# CATALOGUE OSM
# ─────────────────────────────────────────────────────────────────────────────
CATEGORIES = {
    "routes": {
        "label":      "Routes",
        "selectors":  ['way["highway"]'],
        "geom_type":  "line",
        "layer_name": "OSM_Routes",
    },
    "cours_eau": {
        "label":      "Cours d'eau",
        "selectors":  ['way["waterway"]'],
        "geom_type":  "line",
        "layer_name": "OSM_Cours_deau",
    },
    "batiments": {
        "label":      "Bâtiments",
        "selectors":  ['way["building"]'],
        "geom_type":  "polygon",
        "layer_name": "OSM_Batiments",
    },
    "ecoles": {
        "label":      "Établissements scolaires",
        "selectors":  [
            'node["amenity"="school"]',
            'way["amenity"="school"]',
        ],
        "geom_type":  "point",
        "layer_name": "OSM_Ecoles",
    },
    "sante": {
        "label":      "Établissements de santé",
        "selectors":  [
            'node["amenity"~"hospital|clinic|health_centre|doctors|pharmacy"]',
            'way["amenity"~"hospital|clinic|health_centre"]',
        ],
        "geom_type":  "point",
        "layer_name": "OSM_Sante",
    },
}

# ─────────────────────────────────────────────────────────────────────────────
# 1. BBOX
# ─────────────────────────────────────────────────────────────────────────────

def get_bbox_wgs84(layer):
    """
    Retourne (south, west, north, east) en WGS84 depuis une couche QGIS.
    Retourne None si la couche est invalide.
    """
    if layer is None or not layer.isValid():
        return None
    try:
        extent  = layer.extent()
        wgs84   = QgsCoordinateReferenceSystem("EPSG:4326")
        src_crs = layer.crs()

        if src_crs.authid() != "EPSG:4326":
            tr     = QgsCoordinateTransform(src_crs, wgs84, QgsProject.instance())
            extent = tr.transformBoundingBox(extent)

        buf = 0.0005
        return (
            round(extent.yMinimum() - buf, 6),
            round(extent.xMinimum() - buf, 6),
            round(extent.yMaximum() + buf, 6),
            round(extent.xMaximum() + buf, 6),
        )
    except Exception as e:
        log.error(f"Erreur bbox : {e}")
        return None

# ─────────────────────────────────────────────────────────────────────────────
# 2. REQUÊTE OVERPASS
# ─────────────────────────────────────────────────────────────────────────────

def build_query(bbox, category_key):
    """Construit la requête Overpass QL pour une catégorie et une bbox."""
    s, w, n, e = bbox
    bbox_str   = f"{s},{w},{n},{e}"
    lines      = "\n".join(
        f"  {sel}({bbox_str});" for sel in CATEGORIES[category_key]["selectors"]
    )
    return f"[out:json][timeout:60];\n(\n{lines}\n);\nout geom;\n"

# ─────────────────────────────────────────────────────────────────────────────
# 3. TÉLÉCHARGEMENT
# ─────────────────────────────────────────────────────────────────────────────

def fetch_overpass(query):
    """
    Envoie la requête POST à Overpass.
    Retourne (dict_data, None) ou (None, message_erreur).
    """
    if not HAS_REQUESTS:
        return None, (
            "La bibliothèque Python 'requests' est absente.\n"
            "Installez-la : pip install requests"
        )
    try:
        resp = requests.post(
            OVERPASS_URL,
            data={"data": query},
            timeout=60,
            verify=False,
            headers={"User-Agent": "QGIS OSM Extractor Jambar Lab/3.1"},
        )
        resp.raise_for_status()
        data = resp.json()
        log.info(f"Overpass : {len(data.get('elements', []))} éléments reçus")
        return data, None
    except requests.exceptions.Timeout:
        return None, "Délai d'attente dépassé (60 s). Vérifiez votre connexion."
    except requests.exceptions.ConnectionError as e:
        return None, f"Connexion impossible : {e}"
    except requests.exceptions.HTTPError as e:
        return None, f"Erreur HTTP {e.response.status_code}"
    except ValueError as e:
        return None, f"Réponse invalide : {e}"
    except Exception as e:
        return None, f"Erreur inattendue : {e}"

# ─────────────────────────────────────────────────────────────────────────────
# 4. CONVERSION OSM JSON → QgsVectorLayer
# ─────────────────────────────────────────────────────────────────────────────

def osm_to_layer(data, category_key):
    """
    Convertit les données Overpass en QgsVectorLayer mémoire avec index spatial.

    Retourne (QgsVectorLayer, None) ou (None, message_erreur).
    """
    cat       = CATEGORIES[category_key]
    geom_type = cat["geom_type"]
    elements  = data.get("elements", [])

    if not elements:
        return None, "Aucun élément dans cette zone."

    wkb_str = {"point": "Point", "line": "LineString", "polygon": "Polygon"}[geom_type]

    layer    = QgsVectorLayer(f"{wkb_str}?crs=EPSG:4326", cat["layer_name"], "memory")
    provider = layer.dataProvider()

    fields = QgsFields()
    for col in ("osm_id", "osm_type", "name", "category", "tags"):
        fields.append(make_string_field(col))
    provider.addAttributes(fields)
    layer.updateFields()

    count = 0
    for el in elements:
        geom = _to_geom(el, geom_type)
        if geom is None or geom.isEmpty() or not geom.isGeosValid():
            continue
        tags    = el.get("tags", {})
        el_name = tags.get("name") or tags.get("name:fr") or tags.get("name:en") or ""
        cat_val = (tags.get("highway") or tags.get("waterway")
                   or tags.get("building") or tags.get("amenity") or "")

        feat = QgsFeature(layer.fields())
        feat.setGeometry(geom)
        feat["osm_id"]   = str(el.get("id", ""))
        feat["osm_type"] = el.get("type", "")
        feat["name"]     = el_name
        feat["category"] = cat_val
        feat["tags"]     = json.dumps(tags, ensure_ascii=False)[:1000]
        provider.addFeature(feat)
        count += 1

    if count == 0:
        return None, "Données reçues mais aucune géométrie valide extraite."

    layer.updateExtents()

    # ── Index spatial — supprime l'avertissement de native:clip ──────────────
    provider.createSpatialIndex()
    log.info(f"Index spatial créé sur '{cat['layer_name']}' ({count} entités)")

    return layer, None


def _to_geom(el, target):
    """Convertit un élément Overpass en QgsGeometry selon le type cible."""
    try:
        el_type = el.get("type")

        if el_type == "node":
            lat, lon = el.get("lat"), el.get("lon")
            if lat is None:
                return None
            return QgsGeometry.fromPointXY(QgsPointXY(lon, lat))

        if el_type == "way":
            geom_nodes = el.get("geometry", [])
            if len(geom_nodes) < 2:
                return None
            pts = [QgsPointXY(g["lon"], g["lat"]) for g in geom_nodes]

            if target == "line":
                return QgsGeometry.fromPolylineXY(pts)

            if target == "polygon":
                if pts[0] != pts[-1]:
                    pts.append(pts[0])
                if len(pts) < 4:
                    return None
                g = QgsGeometry.fromPolygonXY([pts])
                return g if g.isGeosValid() else g.makeValid()

            if target == "point":
                # Centroïde du way pour les couches ponctuelles
                g = QgsGeometry.fromPolygonXY([pts])
                return g.centroid() if g.isGeosValid() else QgsGeometry.fromPointXY(pts[0])

    except Exception as e:
        log.warning(f"Géométrie ignorée (id={el.get('id')}) : {e}")
    return None

# ─────────────────────────────────────────────────────────────────────────────
# 5. CLIP
# ─────────────────────────────────────────────────────────────────────────────

def clip_layer(layer, clip_source):
    """
    Découpe `layer` selon l'emprise exacte de `clip_source` via native:clip.
    Retourne la couche découpée, ou l'originale en cas d'échec.
    """
    try:
        import processing

        # S'assurer que la couche source a aussi un index spatial
        if hasattr(clip_source.dataProvider(), "createSpatialIndex"):
            clip_source.dataProvider().createSpatialIndex()

        result  = processing.run(
            "native:clip",
            {"INPUT": layer, "OVERLAY": clip_source, "OUTPUT": "memory:"},
        )
        clipped = result.get("OUTPUT")
        if clipped and clipped.isValid() and clipped.featureCount() > 0:
            clipped.setName(layer.name())
            log.info(
                f"Clip OK : {clipped.featureCount()} entités "
                f"(avant clip : {layer.featureCount()})"
            )
            return clipped
        log.warning("Clip : résultat vide, couche d'origine conservée")
        return layer
    except Exception as e:
        log.warning(f"Clip échoué ({e}), couche d'origine conservée")
        return layer
